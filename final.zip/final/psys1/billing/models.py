from django.db import models
from django.contrib.auth.models import User
from encrypted_fields import EncryptedCharField, EncryptedIntegerField, EncryptedDateTimeField

TIPE_CHOICE = (
    ('Parent', u'Parent'),
    ('Student', u'Student'),
)


class Bill(models.Model):
    creator = models.ForeignKey(User, related_name='+')
    created = EncryptedDateTimeField(auto_now_add=True)
    bill_sum = EncryptedIntegerField()
    description = EncryptedCharField(max_length=30)

    def __unicode__(self):
        return self.description

    class Meta:
        verbose_name = 'Bill'
        verbose_name_plural = 'Bills'


class Login(models.Model):
    user = models.ForeignKey(User, related_name='+')
    tipe = EncryptedCharField(max_length=30, choices=TIPE_CHOICE)
    relation = EncryptedCharField(max_length=40, blank=True)

    def __unicode__(self):
        return self.user.username

    class Meta:
        verbose_name = 'Custom user'
        verbose_name_plural = 'Custom users'


 class Student(models.Model):
     student_id = models.AutoField(primary_key=True)
     user = models.ForeignKey(User, related_name='+')
     first_name = models.CharField(max_length=30)
     last_name = models.CharField(max_length=30)
     dob = models.DateTimeField()

     def __unicode__(self):
         return self.student

     class Meta:
         verbose_name = 'Student'
         verbose_name_plural = 'Students'


 class Parent(models.Model):
     parent_id = models.AutoField(primary_key=True)
     parent = models.ForeignKey(User, related_name='+')
     first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    dob = models.DateTimeField()
     parent = models.ForeignKey(Student)

     def __unicode__(self):
         return self.parent

     class Meta:
         verbose_name = 'Parent'
         verbose_name_plural = 'Parents'


# class Bill(models.Model):
#     creator = models.ForeignKey(User, related_name='+')
#     created = models.DateTimeField(auto_now_add=True)
#     bill_sum = models.IntegerField()
#     description = models.CharField(max_length=30)

#     def __unicode__(self):
#         return self.description

#     class Meta:
#         verbose_name = 'Bill'
#         verbose_name_plural = 'Bills'


# class Login(models.Model):
#     user = models.ForeignKey(User, related_name='+')
#     tipe = models.CharField(max_length=30, choices=TIPE_CHOICE)
#     relation = models.CharField(max_length=40, blank=True)

#     def __unicode__(self):
#         return self.user.username

#     class Meta:
#         verbose_name = 'Custom user'
#         verbose_name_plural = 'Custom users'
