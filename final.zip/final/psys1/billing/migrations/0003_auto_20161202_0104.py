# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import encrypted_fields.fields


class Migration(migrations.Migration):

    dependencies = [
        ('billing', '0002_auto_20161129_1229'),
    ]

    operations = [
        migrations.AlterField(
            model_name='bill',
            name='bill_sum',
            field=encrypted_fields.fields.EncryptedIntegerField(),
        ),
        migrations.AlterField(
            model_name='bill',
            name='created',
            field=encrypted_fields.fields.EncryptedDateTimeField(auto_now_add=True),
        ),
        migrations.AlterField(
            model_name='bill',
            name='description',
            field=encrypted_fields.fields.EncryptedCharField(max_length=30),
        ),
        migrations.AlterField(
            model_name='login',
            name='relation',
            field=encrypted_fields.fields.EncryptedCharField(max_length=40, blank=True),
        ),
        migrations.AlterField(
            model_name='login',
            name='tipe',
            field=encrypted_fields.fields.EncryptedCharField(max_length=30, choices=[(b'Parent', 'Parent'), (b'Student', 'Student')]),
        ),
    ]
