from django.contrib import admin
from .models import Bill, Login


admin.site.register(Bill)
admin.site.register(Login)
