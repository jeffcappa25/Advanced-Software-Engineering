# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('billing', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Login',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('tipe', models.CharField(max_length=30, choices=[(b'Parent', 'Parent'), (b'Student', 'Student')])),
                ('relation', models.CharField(max_length=40, blank=True)),
                ('user', models.ForeignKey(related_name='+', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Custom user',
                'verbose_name_plural': 'Custom users',
            },
        ),
        migrations.RemoveField(
            model_name='student',
            name='user',
        ),
        migrations.RemoveField(
            model_name='bill',
            name='bill_id',
        ),
        migrations.AddField(
            model_name='bill',
            name='description',
            field=models.CharField(default='test_bill', max_length=30),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='bill',
            name='id',
            field=models.AutoField(auto_created=True, primary_key=True, default=99, serialize=False, verbose_name='ID'),
            preserve_default=False,
        ),
        migrations.DeleteModel(
            name='Student',
        ),
    ]
