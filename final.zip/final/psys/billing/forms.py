from django import forms
from .models import Bill, Login


class BillForm(forms.ModelForm):
    class Meta:
        model = Bill
        exclude = ('creator', 'created')


class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ('tipe', )
