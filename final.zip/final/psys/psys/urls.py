from django.conf import settings
from django.conf.urls import include, url
from django.conf.urls.static import static
from django.contrib import admin

urlpatterns = [
    # Examples:
    # url(r'^$', 'psys.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^$', 'billing.views.home', name='home'),
    url(r'^dashboard/$', 'billing.views.dashboard', name='dashboard'),
    url(r'^choose_tipe/$', 'billing.views.choose_tipe', name='choose_tipe'),
    url(r'^choose_child/$', 'billing.views.choose_child', name='choose_child'),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^accounts/', include('allauth.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
